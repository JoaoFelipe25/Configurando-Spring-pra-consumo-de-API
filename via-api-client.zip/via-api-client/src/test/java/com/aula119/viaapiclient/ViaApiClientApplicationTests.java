package com.aula119.viaapiclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViaApiClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
